import Layout from '../components/MyLayout';

const about = () => (
  <Layout>
    <p>About page bro</p>
  </Layout>
)

export default about
